# pyTQA
Python Wrapper for the Image Owl Total QA
