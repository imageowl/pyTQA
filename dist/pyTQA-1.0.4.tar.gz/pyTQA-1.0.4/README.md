# pyTQA
Python Wrapper for the Image Owl Total QA

# Instructions for use
pyTQA is now available as a Python Project!
https://pypi.org/project/pyTQA/
To install: pip install pyTQA
To import: import pyTQA
